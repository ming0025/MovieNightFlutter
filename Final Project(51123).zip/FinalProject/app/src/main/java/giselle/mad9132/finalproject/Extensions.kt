package giselle.mad9132.finalproject

import android.content.Context
import android.widget.Toast

/*
* Created by Giselle Mingue Rios on November 21, 2023
*/

fun Context.toast(message : String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}


