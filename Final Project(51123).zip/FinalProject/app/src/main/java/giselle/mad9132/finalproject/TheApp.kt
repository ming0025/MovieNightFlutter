package giselle.mad9132.finalproject

/*
* Created by Giselle Mingue Rios on October 31, 2023
*/

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context

class TheApp: Application() {

    override fun onCreate() {
        super.onCreate()
        context = applicationContext
    }

    // region companion object
    companion object {
        @SuppressLint("StaticFieldLeak")
        lateinit var context: Context
            private set
    }
    // endregion
}