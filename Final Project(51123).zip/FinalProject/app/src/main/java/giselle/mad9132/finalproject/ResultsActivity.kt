package giselle.mad9132.finalproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Layout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import giselle.mad9132.finalproject.databinding.ActivityResultsBinding

class ResultsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityResultsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_results)

        binding = ActivityResultsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val data: ArrayList<User>?

        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            data = intent.getParcelableArrayListExtra(getString(R.string.user_data_key), User::class.java)
        } else {
            @Suppress("DEPRECATION")
            data = intent.getParcelableArrayListExtra(getString(R.string.user_data_key))
        }

        supportActionBar?.title = "${data?.size} Results"

        binding.recyclerViewMain.layoutManager = LinearLayoutManager(this)

        binding.recyclerViewMain.adapter = data?.let {
            CustomerViewHolderClass.MainAdapter(it)
        }

    }


}