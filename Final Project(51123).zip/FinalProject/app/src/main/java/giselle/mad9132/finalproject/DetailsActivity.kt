package giselle.mad9132.finalproject

import android.content.Intent
import android.icu.text.SimpleDateFormat
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.SpannableString
import android.text.style.UnderlineSpan
import com.google.gson.GsonBuilder
import com.squareup.picasso.Picasso
import giselle.mad9132.finalproject.databinding.ActivityDetailsBinding
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.Locale

class DetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = intent.getStringExtra(getString(R.string.details_title_key))

        val url = intent.getStringExtra(getString(R.string.details_url_key))

        val htmlUrl = intent.getStringExtra(getString(R.string.details_html_url_key))

        val content = SpannableString(htmlUrl)

        content.setSpan(UnderlineSpan(), 0, htmlUrl?.length?: 0, 0)
        binding.htmlURLTextView.text = content

        binding.htmlURLTextView.setOnClickListener {
            val intent = Intent(this, WebViewActivity::class.java)
            intent.putExtra(getString(R.string.web_view_url_key), htmlUrl)
            startActivity(intent)
        }

        url?.let {
            fetchJson(it)
        }
    }

    private fun fetchJson(url: String) {

        val request = Request.Builder().url(url).build()

        val client = OkHttpClient()

        client.newCall(request).enqueue(object: Callback {

            override fun onFailure(call: Call, e: IOException) {
                TheApp.context.toast(e.message.toString())
            }

            override fun onResponse(call: Call, response: Response) {

                val body = response.body()?.string()

                val gson = GsonBuilder().create()

                val result = gson.fromJson(body, UserDetails::class.java)

                runOnUiThread {
                    Picasso.get().load(result.avatar_url).into(binding.avatarImageView)
                    binding.nameTextView.text = getString(R.string.user_name, result?.name ?: getString(R.string.unknown))
                    binding.locationTextView.text = getString(R.string.user_location, result?.location ?: getString(R.string.unknown))
                    binding.companyTextView.text = getString(R.string.user_company, result?.company ?: getString(R.string.unknown))
                }
            }
        })

    }


}