package giselle.mad9132.finalproject

import android.content.Context
import android.content.SharedPreferences

/*
* Created by Giselle Mingue Rios on November 10, 2023
*/

// region required resources

@Suppress("UNUSED")
class AppStorage (context: Context) {

    private val preferencesName = context.getString(R.string.app_name)
    private val sharedPreferences : SharedPreferences = context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)

    fun contains(keyName: String) : Boolean {
        return sharedPreferences.contains(keyName)
    }

    fun removeValue(keyName: String) {
        val editor : SharedPreferences.Editor = sharedPreferences.edit()
        editor.remove(keyName)
        editor.apply()
    }

    fun clear() {
        val editor : SharedPreferences.Editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }

    fun getAll() : Map<String, *> {
        return sharedPreferences.all
    }

    // endregion

    // region save methods

    fun save(keyName: String, text: String?) {
        val editor : SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString(keyName, text)
        editor.apply()
    }

    fun save(keyName: String, value: Int) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putInt(keyName, value)
        editor.apply()
    }

    fun save(keyName: String, value: Long) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putLong(keyName, value)
        editor.apply()
    }

    fun save(keyName: String, value: Float) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putFloat(keyName, value)
        editor.apply()
    }

    fun save(keyName: String, value: Boolean) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putBoolean(keyName, value)
        editor.apply()
    }

    fun save(keyName: String, value: Set<String>) {
        val editor: SharedPreferences.Editor = sharedPreferences.edit()
        editor.putStringSet(keyName, value)
        editor.apply()
    }

    // endregion

    // region get methods

    fun getValueString(keyName: String) : String? {
        return sharedPreferences.getString(keyName, null)
    }

    fun getValueInt(keyName: String, defaultValue: Int): Int {
        return sharedPreferences.getInt(keyName, defaultValue)
    }

    fun getValueLong(keyName: String, defaultValue: Long): Long {
        return sharedPreferences.getLong(keyName, defaultValue)
    }

    fun getValueFloat(keyName: String, defaultValue: Float): Float {
        return sharedPreferences.getFloat(keyName, defaultValue)
    }

    fun getValueBoolean(keyName: String, defaultValue: Boolean): Boolean {
        return sharedPreferences.getBoolean(keyName, defaultValue)
    }

    fun getValueSet(keyName: String, defaultValue: Set<String>): Set<String> {
        return sharedPreferences.getStringSet(keyName, defaultValue) ?: defaultValue
    }
    
    // endregion
}