package giselle.mad9132.finalproject

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import giselle.mad9132.finalproject.databinding.DataRowBinding

/*
* Created by Giselle Mingue Rios on November 21, 2023
*/

class CustomerViewHolderClass(
    val view: View,
    var login: String = "",
    var user: User? = null
) : RecyclerView.ViewHolder(view) {

    val binding = DataRowBinding.bind(view)


    class MainAdapter(private val dataSource: ArrayList<User>) : RecyclerView.Adapter<CustomerViewHolderClass>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomerViewHolderClass {
            val layoutInflater = LayoutInflater.from(parent.context)
            val cellForRow = layoutInflater.inflate(R.layout.data_row, parent, false)

            return CustomerViewHolderClass(cellForRow)

        }

        override fun getItemCount(): Int = dataSource.size

        override fun onBindViewHolder(holder: CustomerViewHolderClass, position: Int) {

            holder.binding.loginTextView.text = TheApp.context.getString(R.string.user_login, dataSource[position].login)
            holder.binding.scoreTextView.text = TheApp.context.getString(R.string.user_score, (dataSource[position].score + 0.5).toInt().toString())
            holder.binding.idTextView.text = TheApp.context.getString(R.string.user_id, dataSource[position].id.toString())
            Picasso.get().load(dataSource[position].avatar_url).into(holder.binding.imageView)

            holder.user = dataSource[position]
            holder.login = dataSource[position].login
        }

    }

    init {
        view.setOnClickListener() {
            view.context.toast("Clicked on ${login}")
            val intent = Intent(view.context, DetailsActivity::class.java)

            intent.putExtra(view.context.getString(R.string.details_title_key), login)
            intent.putExtra(view.context.getString(R.string.details_url_key), user?.url)
            intent.putExtra(view.context.getString(R.string.details_html_url_key), user?.html_url)

            view.context.startActivity(intent)
        }
    }
}